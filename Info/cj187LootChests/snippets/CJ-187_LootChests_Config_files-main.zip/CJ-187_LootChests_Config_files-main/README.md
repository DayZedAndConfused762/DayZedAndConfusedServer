# Carters_Chernaurus_Builds
#Dated-15/12/2021    
#Author-killcarter-gaming aka killcarter
#Brief summary

Hey,
I built these build's simply to help some folks spice their Dayz server up and to add more of a challenging aspect to certain location upon the Dayz maps that we all know and love/ish!
please be careful if adding too many builds/settlement's to the one server as too many added structures being addeed to a server can result in a negative effect upon the games central economy/ce, in order to address this issue the central economy/ce will need to be reconfigured to allow for the increase in possible loot spawn locations within said added structures.
There are many tools out there to help with editing the central economy/ce within the game or it can be done manually but will take far more time than using said tools. 
to do it manually, 

#Step-A. you will need to join the server to examine exactly which loot tiers and structures have a deficiency in their overall numbers and take note of said tiers and structures.

#Step-B. increase the the nominal figure "within your missions types.xml file" for the items relevant to the tiers and structures which have been added, ie... "Medical=Bandages,Military=Weapons". it is best to make small increases to the economy at each time and to verify that the changes have had a positive effect upon the economy, it is not a good idea to increase the numbers greatly as this can have a detramental effect upon the games Economy resulting in your servers machine struggling to place said items due to their numbers which results in very poor performance!

#Step-C. Tiers through 1 to 4 should have their relevant items increased in rlation to the tier that the setlement has been placed within, which is lacking loot spawning within it.

#Step-D. Structures that have been added have a specific type attributed to them which relates to the type of structure they are "ie... Medical,Military..ect." take note of the type of structures lacking loot and increase the relevant items which would be associated with those type of building's "ie..Medical=Bandage's,rag's...ect. Military=Weapon's,Ammo..ect"

#Step-E. rejoin the server and evaluate what effect your changes have had upon the economy and gage as best you can how much more of an increase should be attritud to the items nominal value in order to see an improvement.

#Step-F. Repeat the previous steps until you reach a satisfactory level of loot spawning withing the structures you have placed.

#Reminder,
This is a very time consuming task as after each increase it will take prolonged periods of time in order for the loot within the games ecomomy to cycle through before any eccect which was made to become evident within the world. if possible it is best to use an Economy editor tool which will complete the task in a shorter time frame. doing this task manually may take some time depending upon the overall figures of loot at which your types file contained including added mods! 


#LICENCED Under ADPLSA

 This is a collection of the Special/Settlemnet's/Military/Medical/Trader/Builds/Facilities that "killcarter-gaming aka killcarter" has built to be shared freely and publicly amongst the "Dayz" player base community.
 These "Special/Settlemnet's/Military/Medical/Trader/Builds/Facilities, shall be referred too as Data from hence forth" are built for a Dayz Chernaurus server.
 Under no circumstances shall any person/s receive monetary gains from the distribution "sale,loan,lease,purchase or any other form of distribution means" of this data.
 Furthermore, "killcarter-gaming aka killcarter" shall not be held liable in any form for the distribution of altered or fraudulant forms of this data.
 all data which is posted/published by "killcarter-gaming aka killcarter" which is then altered/changed in any way or form by another person,
 shall then see that other person assume all responsibility and be held liable for any and all changes they have done to the said data.
 

